import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

class DatabaseCon {
    static String url = "jdbc:mysql://LAPTOP-92F8QJLK:3306/words";
    static String user = "pablo";
    static String pass = "10102022";
    static String table = "";

    static List<Game.Word> getWords() {
        List<Game.Word> words = new ArrayList<>();
        String sql = "SELECT word, meaning FROM " + table;

        try (
            Connection conn = DriverManager.getConnection(url, user, pass);
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()
        ) {
            while (rs.next()) {
                String name = rs.getString("word");
                String meaning = rs.getString("meaning");
                words.add(new Game.Word(name, meaning));
            }
        } catch (SQLException e) {
            System.out.println("Erro ao acessar o banco: " + e.getMessage());
        }

        return words;
    }
}
