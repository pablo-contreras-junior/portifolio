import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Game {
    static boolean running = true;
    static boolean playByTranslating = false;

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("NOME DA TABELA: ");
        String table = keyboard.nextLine().toLowerCase().trim().replace(' ', '_');
        DatabaseCon.table = table;

        List<Word> wordsGroup = DatabaseCon.getWords();

        while (running) {
            startRound(keyboard, wordsGroup);
        }

        keyboard.close();
    }

    static void startRound(Scanner keyboard, List<Word> wordsGroup) {
        if (wordsGroup.isEmpty()) {
            System.out.println("\n\n🎉 PARABÉNS!\nVOCÊ COMPLETOU TODAS AS PALAVRAS!");
            running = false;
            return;
        }

        Word word = getRandomWord(wordsGroup);

        String question = playByTranslating ? word.meaning() : word.name();
        String expectedAnswer = playByTranslating ? word.name() : word.meaning();

        System.out.print("\n[1] Sair   [2] Mudar Modo\n\n" + question + " -> ");
        String guess = keyboard.nextLine().trim();

        switch (guess) {
            case "1":
                running = false;
                break;
            case "2":
                playByTranslating = !playByTranslating;
                wordsGroup.add(word); // devolve a palavra
                break;
            default:
                if (guess.equalsIgnoreCase(expectedAnswer)) {
                    System.out.println("Correto!");
                } else {
                    System.out.println("Resposta correta: " + expectedAnswer);
                    wordsGroup.add(word); // devolve a palavra
                }
                break;
        }
    }

    static Word getRandomWord(List<Word> list) {
        int index = new Random().nextInt(list.size());
        return list.remove(index);
    }

    // Classe auxiliar para clareza
    record Word(String name, String meaning) {}
}
