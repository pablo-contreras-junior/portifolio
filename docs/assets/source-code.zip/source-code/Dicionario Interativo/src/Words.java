import java.util.Scanner;

class Words {
    static boolean running = true;

    static void run(Scanner teclado) {
        System.out.println();
        DataHandle.show();

        System.out.print("\n1 - Adicionar palavra | 2 - Buscar | 3 - Sair\nEscolha: ");

        int input;
        try {
            input = Integer.parseInt(teclado.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Comando inválido. Por favor, digite um número válido.");
            return;
        }

        switch (input) {
            case 1 -> {
                System.out.print("Palavra: ");
                String palavra = teclado.nextLine().trim().toLowerCase();

                System.out.print("Significado: ");
                String significado = teclado.nextLine().trim().toLowerCase();

                DataHandle.add(palavra, significado);
                System.out.println("Palavra adicionada com sucesso!");
            }
            case 2 -> {
                System.out.print("Buscar palavra: ");
                String busca = teclado.nextLine().trim().toLowerCase();

                String resultado = DataHandle.search(busca);
                System.out.println(resultado);
            }
            case 3 -> {
                System.out.println("Até breve!");
                running = false;
            }
            default -> System.out.println("Comando inválido.");
        }
    }

    public static void main(String[] args) {
        try (Scanner teclado = new Scanner(System.in)) {
            System.out.print("NOME DA TABELA: ");
            String table = teclado.nextLine().toLowerCase().trim().replace(' ', '_');
            DataHandle.table = table;

            while (running) {
                run(teclado);
            }
        }
    }
}
