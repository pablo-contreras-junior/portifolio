import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class DataHandle {

    static final String URL = "jdbc:mysql://LAPTOP-92F8QJLK:3306/words";
    static final String USER = "pablo";
    static final String PASS = "10102022";
    static String table = "";

    static void show() {
        final int MAX_RESULTS = 12;
        String sql = "SELECT word, meaning FROM " + table + " ORDER BY occurrences DESC";

        try (
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {
            if (!rs.isBeforeFirst()) {
                System.out.println("\tNenhuma palavra disponível.");
                return;
            }

            int count = 0;
            while (rs.next() && count < MAX_RESULTS) {
                String word = rs.getString("word");
                String meaning = rs.getString("meaning");
                System.out.printf("\t%-16s -> %s%n", word, meaning);
                count++;
            }

            if (rs.next()) {
                System.out.println("\t. . .");
            }

        } catch (SQLException e) {
            System.out.println("Erro ao mostrar palavras: " + e.getMessage());
        }
    }

    static String search(String request) {
        String sql = "SELECT * FROM " + table + " WHERE word = ?";

        try (
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql)
        ) {
            ps.setString(1, request);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return "\tPalavra não encontrada.";
                }

                int id = rs.getInt("id");
                int occurrences = rs.getInt("occurrences");
                String word = rs.getString("word");
                String meaning = rs.getString("meaning");

                // Atualiza ocorrências
                String updateSql = "UPDATE " + table + " SET occurrences = ? WHERE id = ?";
                try (PreparedStatement update = conn.prepareStatement(updateSql)) {
                    update.setInt(1, occurrences + 1);
                    update.setInt(2, id);
                    update.executeUpdate();
                }

                return "\t" + word + " -> " + meaning;
            }

        } catch (SQLException e) {
            System.out.println("Erro ao buscar palavra: " + e.getMessage());
            return "\tPalavra não encontrada.";
        }
    }

    static void add(String word, String meaning) {
        String sql = "INSERT INTO " + table + " (word, meaning, occurrences) VALUES (?, ?, ?)";

        try (
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql)
        ) {
            ps.setString(1, word);
            ps.setString(2, meaning);
            ps.setInt(3, 1);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar palavra: " + e.getMessage());
        }
    }
}
