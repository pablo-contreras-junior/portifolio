import java.sql.*;

public class DataManager {

    private static final String URL = "jdbc:mysql://LAPTOP-92F8QJLK:3306/livros";
    private static final String USER = "pablo";
    private static final String PASS = "10102022";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void insertBook(String nome, int numOfPages) {
        String sql = "INSERT INTO dados (nome, comp) VALUES (?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setInt(2, numOfPages);
            stmt.executeUpdate();

            System.out.println("✅ Livro inserido com sucesso!");

        } catch (SQLException e) {
            System.err.println("❌ Erro ao inserir livro:");
            e.printStackTrace();
        }
    }

    public static String removeBook(int id) {
        String sql = "DELETE FROM dados WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();

            return rows > 0 ? "✅ Livro removido com sucesso!" : "⚠️  Nenhum livro com esse ID.";

        } catch (SQLException e) {
            System.err.println("❌ Erro ao remover livro:");
            e.printStackTrace();
            return "Erro ao remover o livro.";
        }
    }

    public static void markPage(int pg, int id) {
        String sql = "UPDATE dados SET pagina = ? WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, pg);
            stmt.setInt(2, id);
            int rows = stmt.executeUpdate();

            if (rows > 0) {
                System.out.println("✅ Página atualizada!");
            } else {
                System.out.println("⚠️  ID não encontrado.");
            }

        } catch (SQLException e) {
            System.err.println("❌ Erro ao atualizar página:");
            e.printStackTrace();
        }
    }

    public static void printOptions() {
        String sql = "SELECT * FROM dados ORDER BY id";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n📚 LIVROS CADASTRADOS:\n");

            if (!rs.isBeforeFirst()) {
                System.out.println("  Nenhum livro encontrado.");
                return;
            }

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                int pg = rs.getInt("pagina");
                int length = rs.getInt("comp");
                int percent = (length == 0) ? 0 : (pg * 100 / length);

                System.out.printf("  %-3d - %-42s | Pág: %-5d | %s%n",
                        id,
                        nome,
                        pg,
                        (length == 0 ? "Sem total" : percent + "%"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Erro ao listar livros:");
            e.printStackTrace();
        }
    }
}
