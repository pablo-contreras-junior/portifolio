import java.util.Scanner;

class Mark {
    private static boolean running = true;
    private static final Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            while (running) {
                showMenu();
                handleUserInput();
            }
        } finally {
            teclado.close();
            System.out.println("Programa finalizado.");
        }
    }

    private static void showMenu() {
        System.out.println("\n--- MENU ---");
        System.out.println("1 - Adicionar livro");
        System.out.println("2 - Marcar página");
        System.out.println("3 - Remover livro");
        System.out.println("4 - Sair");
        System.out.println("\n--- LIVROS ---");
        DataManager.printOptions();
        System.out.print("\nEscolha uma opção: ");
    }

    private static void handleUserInput() {
        int choice = readInt();

        switch (choice) {
            case 1 -> addBook();
            case 2 -> markPage();
            case 3 -> removeBook();
            case 4 -> exit();
            default -> System.out.println("⚠️  Comando inválido!");
        }
    }

    private static void addBook() {
        System.out.print("Nome do livro: ");
        teclado.nextLine(); // Limpa buffer do nextInt anterior
        String nome = teclado.nextLine();

        System.out.print("Número de páginas: ");
        int pages = readInt();

        DataManager.insertBook(nome, pages);
        System.out.println("✅ Livro adicionado com sucesso!");
    }

    private static void removeBook() {
        System.out.print("ID do livro a remover: ");
        int id = readInt();
        String resultado = DataManager.removeBook(id);
        System.out.println("📌 " + resultado);
    }

    private static void markPage() {
        System.out.print("ID do livro: ");
        int id = readInt();

        System.out.print("Página atual: ");
        int pg = readInt();

        DataManager.markPage(pg, id);
        System.out.println("✅ Página marcada!");
    }

    private static void exit() {
        System.out.println("👋 Até a próxima!");
        running = false;
    }

    private static int readInt() {
        while (!teclado.hasNextInt()) {
            System.out.print("Entrada inválida. Digite um número: ");
            teclado.next(); // descarta o input errado
        }
        return teclado.nextInt();
    }
}